import React, {useState} from 'react'
import Dashboard from './Pages/Dashboard'
import SideBar from './Components/Sidebar'
import Login from './Pages/Login'

const App = () => {
  const [IsLogin, setIsLogin] = useState(false);
  return (
    <div className='w-screen h-dvh p-0 m-0 overflow-hidden bg-white text-black'>
      <Dashboard />
        {IsLogin? <Login setIsLogin={setIsLogin}/> : <Dashboard setIsLogin={setIsLogin}/>}
    </div>
  )
}

export default App