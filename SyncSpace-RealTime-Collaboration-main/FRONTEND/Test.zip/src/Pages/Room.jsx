import React from 'react'

const Room = () => {
  return (
    <div className='text-2xl'>
      Rooms are here!!!
    </div>
  )
}

export default Room