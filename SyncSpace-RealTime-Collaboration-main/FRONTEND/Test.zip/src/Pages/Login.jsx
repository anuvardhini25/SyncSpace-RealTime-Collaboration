import React, {useEffect} from 'react'

const Login = ({setIsLogin}) => {
  const LoginBtn = () => {
    console.log('Login button clicked');
  }
  return (
    <div className='bg-white h-[80%] w-[50%] border border-slate-400 flex justify-center items-center'>
      <h1 className='text-2xl'>Login Here</h1>
    </div>
  )
}

export default Login