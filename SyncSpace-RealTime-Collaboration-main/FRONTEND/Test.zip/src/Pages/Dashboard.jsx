import React from "react";
import SideBar from "../Components/Sidebar";
import DashboardContent from "../Components/DashboardContent";

const Dashboard = ({setIsLogin}) => {
  console.log('Dashboard rendered',setIsLogin);
  return (
    <div className="w-full h-dvh bg-white flex flex-row">
      <SideBar setIsLogin={setIsLogin} />
      <DashboardContent/>
    </div>
  );
};

export default Dashboard;
