import React from "react";
import { MdAdd } from "react-icons/md";
import backgroundImage from "../assets/DashboardBG.png";

const DashboardContent = () => {
  return (
    <div className="flex flex-col h-vh ">
      <div className="flex flex-row h-dvh gap-10">
        <div>
          <h1 className="text-3xl font-bold p-20">Wellcome Here!!</h1>
          <p className="text-lg text-gray-600 relative bottom-15 left-20">
            Here's what's happening with your teams today.
          </p>
        </div>
        <div>
          <button className="bg-purple-900 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded relative top-20 left-130 flex flex-row items-center gap-2" >
            <MdAdd />
            Create Room
          </button>
        </div>
      </div>

      <div className="flex flex-row gap-10 p-20">
        <div className="flex flex-col gap-2 border px-13 py-5 rounded-md shadow-md border-slate-300 text-gray-500">
            <div>Total Rooms</div>
            <div>_</div>
        </div>
        <div className="flex flex-col gap-2 border px-13 py-5 rounded-md shadow-md border-slate-300 text-gray-500">
            <div>Active Rooms</div>
            <div>_</div>
        </div>
        <div className="flex flex-col gap-2 border px-13 py-5 rounded-md shadow-md border-slate-300 text-gray-500">
            <div>Team Members</div>
            <div>_</div>
        </div>
      </div>

      <div className="flex flex-row gap-180 p-20 ">
        <h2 className="text-2xl font-bold">Your Rooms</h2>
        <input placeholder="Search rooms..." className="border rounded-md py-2 px-4"/>
      </div>
    </div>
  );
};

export default DashboardContent;
