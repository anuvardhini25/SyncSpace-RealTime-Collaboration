import React, { useState } from 'react'
import logo from '../assets/Logo.png'
import Login from '../Pages/Login'

const SideBar = ({ setIsLogin  }) => {
  console.log('Sidebar rendered', setIsLogin);
  const handleLoginClick = () => {
    if (typeof setIsLogin === 'function') {
      console.log('Login button clicked, setIsLogin is a function');
      setIsLogin(true);
    } else {
      console.error("setIsLogin prop is missing");
    }
  };

  return (
    <div className='h-dvh w-1/6 bg-slate-900 text-white flex flex-col  gap-10'>
            <div className='flex flex-row items-center'>
              <img src={logo} className='h-20 w-20' alt="404" />
              <h2 className='text-3xl font-bold relative'>SyncSpace</h2>
            </div> 

            <div className='flex flex-col gap-5 p-4 text-2xl '>
              <button className='hover:cursor-pointer hover:scale-105 hover:border hover:border-slate-400 hover:rounded-md' type='button' onClick={() => (window.location.href = '/dashboard')}>
                Dashboard
              </button>

              <button className='hover:cursor-pointer hover:scale-105 hover:border hover:border-slate-400 hover:rounded-md' type='button' onClick={() => (window.location.href = '/Room')}>
                Room
              </button>
            </div>

            <div>
              <hr className='relative top-90 border-b border-slate-800' />
              <button className='text-2xl items-center relative top-97 px-10 hover:cursor-pointer hover:scale-105 hover:border-slate-400'
              type='button'
                onClick={() => setIsLogin(true)}>{
                }
                Login In
              </button>
            </div>
    </div>
  )
}

export default SideBar